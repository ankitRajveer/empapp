import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admincontent',
  templateUrl: './admincontent.component.html',
  styleUrls: ['./admincontent.component.css']
})
export class AdmincontentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
